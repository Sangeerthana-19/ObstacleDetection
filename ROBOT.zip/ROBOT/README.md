# custom_bot


roslaunch custom_bot custom_bot.launch 

rosrun teleop_twist_keyboard teleop_twist_keyboard.py

rosrun custom_bot obstacle.py
